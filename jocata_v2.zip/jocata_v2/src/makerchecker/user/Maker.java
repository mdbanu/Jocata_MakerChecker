package makerchecker.user;

import makerchecker.trans.ManageTransaction;
import makerchecker.trans.Transaction;
import makerchecker.trans.TransactionInfo;

/*
 * This class is responsible for Creating Transactions
 * Maker can create, update and delete transactions
 */
public class Maker extends User {

	ManageTransaction mt;

	/*
	 * To create Transactions
	 * 
	 */
	public Transaction createTransaction(TransactionInfo transactionInfo) {
		
		/*
		 * create  Transaction object with the details available in TransactionInfo
		 * set  the user as Maker in the transaction object
		 * 
		 */
		Transaction tranasaction = new Transaction();
		//set all parameters
		return tranasaction;
		
	

	}

	/*
	 * To update Transactions
	 * 
	 */
	public Transaction updateTransaction(Transaction request) {
		/*
		 * Here the Maker will change the transaction details and update the 
		 * status of the transaction as UPDATE
		 */
		return null;
	}

	/*
	 * To delete Transactions
	 * 
	 */
	public Transaction deleteTransaction(Transaction request) {
		/*
		 * Here the Maker will delete the transaction and update the 
		 * status of the transaction as DELETE
		 */
		return null;
	}
	

}
