package makerchecker.user;

import java.util.List;

import makerchecker.roles.UserRoles;
import makerchecker.trans.Transaction;


public class User {

	private int userId;

	private String userName;

	private UserRoles userRole;
	
	private List<Transaction> transactionList;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public UserRoles getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRoles userRole) {
		this.userRole = userRole;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public List<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	
	// other user related details

}
