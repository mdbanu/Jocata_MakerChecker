package makerchecker.user;

import makerchecker.trans.ManageTransaction;
import makerchecker.trans.Transaction;

/*
 * This is a check class 
 * Checker can approve, reject and can ask for more info(needMoreInfo) transactions
 */
public class Checker extends User{
	
	ManageTransaction mt ;
	
	/*
	 * This method is responsible for Approving Transactions
	 */
	public Transaction approveTransaction(Transaction request) {
		
		/*
		 * Here the Checker can either APPROVE/REJECT/REVIEW (ASK for more details inorder to approve it)
		 * 
		 */
		return request;
		
		
	}
	/*
	 * Checker can Reject transactions
	 */
	public Transaction rejectTransaction(Transaction request)
	{
		/*
		 * Checker will reject the transaction and update the status of the transaction 
		 * as REJECT with appropriate comments
		 */
		return request;		
	}
	/*
	 * checker can send it back to the Maker to provide more info
	 */
	
	public Transaction needMoreInfo(Transaction request)
	{
		/*
		 * Checker will send it back to the Maker for more details and update the status of the transaction 
		 * as REVIEW with appropriate comments
		 */
		return request;		
	}

}

