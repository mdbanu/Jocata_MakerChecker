package makerchecker.user;
/*
 * This pojo has all user related information to create a User
 */
public class UserInfo {
	
	String name;
	
	int userId;
	
	String role;
	
	//all user info

}
