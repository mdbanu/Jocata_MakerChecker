package makerchecker.roles;

public enum UserRoles {
	//define all the grades in this file
	GRADE5, GRADE10, GRADE15, GRADE20, ADMIN, SUPERUSER

}
