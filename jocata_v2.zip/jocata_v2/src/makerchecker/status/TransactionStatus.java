package makerchecker.status;
public enum TransactionStatus {

	 REVIEW, APPROVED, REJECTED, CREATE, UPDATE, DELETE, NEW, FAILED, SUCCESS

}
