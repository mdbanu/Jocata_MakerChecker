package makerchecker.trans.impl;

import makerchecker.status.TransactionStatus;
import makerchecker.trans.ManageTransaction;
import makerchecker.trans.Transaction;
import makerchecker.trans.TransactionInfo;
import makerchecker.user.User;
import makerchecker.user.UserInfo;

public class ManageTransactionImpl implements ManageTransaction {

	@Override
	public TransactionStatus createTransaction(TransactionInfo transactionInfo) {
		
		/*
		 * From the transactionInfo we know the who has created the transaction
		 * create a Maker object with the details available in transactionInfo
		 * and invoke createTransaction in Maker class
		 * 	
		*/ 
		/*
		 * Maker will create the transaction and return the Transaction 
		 * 
		 * After getting the Transaction object, use some eventing mechanism (Queue/kafka Topic/Inbox)
		 * 
		 * Depending on the status of transactions we can have n different queues for n diffrent 
		 * transactions based on their status
		 
		 * For Eg: you are putting this transaction in a Queue called TransactionQueue 
		 * 
		 * And you can persist the transaction  in the Database/Distributed Cache along with the status 
		 * of the transaction
		 */
		
		
		 try {
			 // TO DO
			 // 
			 // get the transaction from Maker and raise an event with the Transaction Data
			 // Transaction Status =  =NEW/CREATE
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }

		
	}

	@Override
	public TransactionStatus updateTransaction(Transaction request) {
		// TODO Auto-generated method stub
		try {
			request.getCreatedByUser().updateTransaction(request);
			/* After getting the Transaction object from Maker, event is raised to
			 *  (Queue/kafka Topic/Inbox)
			 *  Transaction Status =  UPDATE
			 */
			 
			
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }
	}

	@Override
	public TransactionStatus deleteTransaction(Transaction request) {
		try {
			request.getCreatedByUser().deleteTransaction(request);
			/* After getting the Transaction object from Maker, event is raised to
			 *  (Queue/kafka Topic/Inbox)
			 *  and return that transaction is successfully deleted.
			 *  
			 *  	Transaction Status = DELETE		
			  */
			
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }
	}
	@Override
	public TransactionStatus approveTransaction(Transaction request) {
		// TODO Auto-generated method stub
		try {
			request.getApprovedByUser().approveTransaction(request);
			/* After getting the Transaction object from Checker  again raise an event
			 *  (Queue/kafka Topic/Inbox)
			 *  Here the status of the transaction can be APPROVE/REVIEW/REJECT
			 */
			 
			//Transaction Status = APPROVED
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }

	}

	

	

	@Override
	public TransactionStatus rejectTransaction(Transaction request) {
		// TODO Auto-generated method stub
		try {
			request.getApprovedByUser().rejectTransaction(request);
			/* After getting the Transaction object from Checker and again raise an event
			 *  (Queue/kafka Topic/Inbox)
			 */
			//Transaction Status = REJECT
			
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }
	}
	
	@Override
	public TransactionStatus needMoreInfo(Transaction request) {
		try {
			request.getApprovedByUser().needMoreInfo(request);
			/* After getting the Transaction object from Checker and again raise an event
			 *  (Queue/kafka Topic/Inbox)
			 */
			 
			//Transaction Status = REVIEW
			return TransactionStatus.SUCCESS;
		 }
		 catch(Exception e) {
			 return TransactionStatus.FAILED;
		 }
	}

	@Override
	/*
	 * (non-Javadoc)
	 * @see makerchecker.trans.ManageTransaction#createUser()
	 */
	public User createUser(UserInfo userInfo) {
		// TODO Auto-generated method stub
		User user = null ;//create user object
		return user;
	}

	@Override
	public TransactionStatus assignTransactionToUser(Transaction request) {
		// TODO Auto-generated method stub
		/* We have the checker information in the transaction
		 * add the the transaction to the list
		 */
		try {
			// add the request to transactionList
			return TransactionStatus.SUCCESS;
		}
		catch(Exception e) {
			return TransactionStatus.FAILED;
		}
	}

	

	

	
}
