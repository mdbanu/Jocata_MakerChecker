package makerchecker.trans;

import makerchecker.status.TransactionStatus;
import makerchecker.user.User;
import makerchecker.user.UserInfo;

/*
 * ManageTransaction will manage all the transactions of Maker and Checker
 */
public interface ManageTransaction {
	
	/*
	 * This API will manage all the transactions
	 */
	public User createUser(UserInfo userInfo);
	

	public TransactionStatus createTransaction(TransactionInfo transactionInfo);
	
	public TransactionStatus updateTransaction(Transaction request);

	public TransactionStatus deleteTransaction(Transaction request);
	

	public TransactionStatus approveTransaction(Transaction request);

	public TransactionStatus needMoreInfo(Transaction request);
	
	public TransactionStatus rejectTransaction(Transaction request);
	
	
	public TransactionStatus assignTransactionToUser(Transaction request);
	
	
	

}
