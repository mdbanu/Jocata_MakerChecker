package makerchecker.trans;

import makerchecker.roles.UserRoles;
import makerchecker.status.TransactionStatus;

/**
 * 
 * This class contains all transaction related data
 * User who is creating the transaction 
 * Transaction related info
 *
 */
public class TransactionInfo {
	
    int transId;	
	
	int userId;

	TransactionStatus transactionStatus;

	String createdByUser;
	
	UserRoles createdByUserRole;

	String createdForUser;

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}

	public UserRoles getCreatedByUserRole() {
		return createdByUserRole;
	}

	public void setCreatedByUserRole(UserRoles createdByUserRole) {
		this.createdByUserRole = createdByUserRole;
	}

	public String getCreatedForUser() {
		return createdForUser;
	}

	public void setCreatedForUser(String createdForUser) {
		this.createdForUser = createdForUser;
	}
	
	// all other details
	
	

}
