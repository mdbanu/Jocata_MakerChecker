package makerchecker.trans;

import java.sql.Timestamp;

import makerchecker.status.TransactionStatus;
import makerchecker.user.Checker;
import makerchecker.user.Maker;

public class Transaction {
	
	int transId;
	
	String transType;
	
	TransactionStatus transactionStatus;
	
	String reasonForRejection;
	
	String comments;
	
	Maker createdByUser;
	
	Checker approvedByUser;
	
	Timestamp createdTimeStamp;
	
	Timestamp approvedTimeStamp;
	
	Timestamp updatedTimeStamp;

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public Maker getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Maker createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Checker getApprovedByUser() {
		return approvedByUser;
	}

	public void setApprovedByUser(Checker approvedByUser) {
		this.approvedByUser = approvedByUser;
	}

	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public Timestamp getApprovedTimeStamp() {
		return approvedTimeStamp;
	}

	public void setApprovedTimeStamp(Timestamp approvedTimeStamp) {
		this.approvedTimeStamp = approvedTimeStamp;
	}

	public Timestamp getUpdatedTimeStamp() {
		return updatedTimeStamp;
	}

	public void setUpdatedTimeStamp(Timestamp updatedTimeStamp) {
		this.updatedTimeStamp = updatedTimeStamp;
	}

	public String getReasonForRejection() {
		return reasonForRejection;
	}

	public void setReasonForRejection(String reasonForRejection) {
		this.reasonForRejection = reasonForRejection;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
	
	
	
	//other transaction related data
	
	

}
