package makerchecker.processor;

import makerchecker.trans.ManageTransaction;
import makerchecker.trans.Transaction;

/*
 * This class is subscriber to the TransactionQueue
 * and will process the messages 
 * Listener to the TransactionQueue in which the transactions are raised
 * 
 * There can be N number of such processors and this is an asynchronous message processing
 */
public class TransactionProcessor {
	
	ManageTransaction mt ;
	
	

	public ManageTransaction getMt() {
		return mt;
	}



	public void setMt(ManageTransaction mt) {
		this.mt = mt;
	}



	void processTransaction(Transaction transac) {
		/*
		 * check the status of the transaction and process the message further
		 * 
		 * Status = NEW/CREATE/UPDATE,
		 *  which means it has to go thru the approval flow
		 * and the decision of approver/checker will be depending on the roles
		 * and depending on the checks the respective system has
		 * It is also possible to
		 * automate the selection of reviewers based on the type of transaction and
		 * roles of the users using pre-configured mappings of who can review what type
		 * of transactions. Throughout this process, the properties of transaction are
		 * updated to facilitate the status checks by any users.
		 */
		
		 /* After deciding the Checker add this transactions to the checkers account
		  * Idea is to provide an UI where  the user will be able to see in the transactions
		  * which he has to act upon
		  */
		
		/*
		 * Status = REVIEW (asked for more details)
		 * Add this transaction to Makers transactionlist, He can make the necessary changes and 
		 * submit it back for approval, with satus = UPDATE
		 * 
		 * 
		 */
		
		/* Status = APPROVED/REJECT 
		 * 
		 * If the status is APPROVED/REJECT the workflow is completed for that transaction 
		 * add this transaction to Makers list, for him to know the transaction is APPROVED/REJECT
		 * but it has no action attached to it
		 * You can log the transaction (file system, DB, etc ) for auditing purposes
		 * 
		 * 
		 */
		
		
	}
	
}
